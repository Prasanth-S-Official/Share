from flask import Flask, render_template, request, redirect, url_for, flash
from db_config import get_connection

app = Flask(__name__)
app.secret_key = 'apy'  # Needed for flash messages

@app.route('/')
def index():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM tasks")
    tasks = cur.fetchall()
    conn.close()
    return render_template("index.html", tasks=tasks)

@app.route('/add', methods=['GET', 'POST'])
def add():
    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        priority = request.form['priority']
        due_date = request.form['due_date']
        status = request.form['status']
        conn = get_connection()
        cur = conn.cursor()
        cur.execute('''
            INSERT INTO tasks (title, description, priority, due_date, status)
            VALUES (%s, %s, %s, %s, %s)
        ''', (title, description, priority, due_date, status))
        conn.commit()
        conn.close()
        flash("Task added successfully!", "success")
        return redirect(url_for('index'))
    return render_template('add.html')

@app.route('/edit/<int:id>', methods=['GET', 'POST'])
def edit(id):
    conn = get_connection()
    cur = conn.cursor()
    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        priority = request.form['priority']
        due_date = request.form['due_date']
        status = request.form['status']
        cur.execute('''
            UPDATE tasks
            SET title=%s, description=%s, priority=%s, due_date=%s, status=%s
            WHERE id=%s
        ''', (title, description, priority, due_date, status, id))
        conn.commit()
        conn.close()
        flash("Task updated!", "info")
        return redirect(url_for('index'))
    cur.execute("SELECT * FROM tasks WHERE id=%s", (id,))
    task = cur.fetchone()
    conn.close()

    # ✅ Pre-format due_date for HTML
    if task[4]:  # task[4] is due_date
        formatted_task = list(task)
        formatted_task[4] = formatted_task[4].strftime('%Y-%m-%d')
        task = tuple(formatted_task)

    return render_template('edit.html', task=task)


@app.route('/delete/<int:id>')
def delete(id):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM tasks WHERE id=%s", (id,))
    conn.commit()
    conn.close()
    flash("Task deleted!", "danger")
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True, host="0.0.0.0", port=8080)
