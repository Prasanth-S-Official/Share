# db_config.py
import sqlite3

DB_PATH = "appdb.sqlite"

def get_connection():
    # Return rows as tuples for compatibility with existing templates
    return sqlite3.connect(DB_PATH)

def init_db():
    conn = get_connection()
    cur = conn.cursor()

    # Users table
    cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    """)

    # Tasks table (original columns)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT,
            priority TEXT,
            due_date TEXT,
            status TEXT
        )
    """)

    # Ensure user_id exists (migration without data loss)
    cur.execute("PRAGMA table_info(tasks)")
    cols = [c[1] for c in cur.fetchall()]
    if "user_id" not in cols:
        cur.execute("ALTER TABLE tasks ADD COLUMN user_id INTEGER")

    conn.commit()
    conn.close()
