# from flask import Flask, render_template, request, redirect, url_for, flash, Response, session
# from flask_login import LoginManager, login_user, login_required, logout_user, current_user, UserMixin
# from werkzeug.security import generate_password_hash, check_password_hash
# from db_config import get_connection, init_db
# from datetime import datetime, date
# import csv
# from io import StringIO

# app = Flask(__name__)
# app.secret_key = 'apy'

# # Flask-Login setup
# login_manager = LoginManager(app)
# login_manager.login_view = "login"


# # User model for Flask-Login
# class User(UserMixin):
#     def __init__(self, id_, username, email, password):
#         self.id = id_
#         self.username = username
#         self.email = email
#         self.password = password


# @login_manager.user_loader
# def load_user(user_id):
#     conn = get_connection()
#     cur = conn.cursor()
#     cur.execute("SELECT * FROM users WHERE id=?", (user_id,))
#     row = cur.fetchone()
#     conn.close()
#     if row:
#         return User(row[0], row[1], row[2], row[3])
#     return None


# # ----------------- AUTH ROUTES -----------------
# @app.route("/register", methods=["GET", "POST"])
# def register():
#     if request.method == "POST":
#         username = request.form["username"].strip()
#         email = request.form["email"].strip()
#         password = generate_password_hash(request.form["password"])

#         conn = get_connection()
#         cur = conn.cursor()
#         try:
#             cur.execute("INSERT INTO users (username, email, password) VALUES (?, ?, ?)",
#                         (username, email, password))
#             conn.commit()
#             flash("Registration successful! Please log in.", "success")
#             return redirect(url_for("login"))
#         except Exception:
#             flash("Username or Email already exists.", "danger")
#         finally:
#             conn.close()
#     return render_template("register.html")


# @app.route("/login", methods=["GET", "POST"])
# def login():
#     if request.method == "POST":
#         email = request.form["email"].strip()
#         password = request.form["password"]

#         conn = get_connection()
#         cur = conn.cursor()
#         cur.execute("SELECT * FROM users WHERE email=?", (email,))
#         user = cur.fetchone()
#         conn.close()

#         if user and check_password_hash(user[3], password):
#             user_obj = User(user[0], user[1], user[2], user[3])
#             login_user(user_obj)
#             flash("Login successful!", "success")
#             return redirect(url_for("index"))
#         else:
#             flash("Invalid credentials!", "danger")

#     return render_template("login.html")


# @app.route("/logout")
# @login_required
# def logout():
#     logout_user()
#     flash("You have been logged out.", "info")
#     return redirect(url_for("login"))


# # ----------------- TASK ROUTES -----------------
# @app.route("/")
# @login_required
# def index():
#     filter_status = request.args.get('filter')
#     search_query = request.args.get('search', '').strip()

#     conn = get_connection()
#     cur = conn.cursor()

#     sql = "SELECT * FROM tasks WHERE user_id=?"
#     params = [current_user.id]

#     if filter_status:
#         sql += " AND status=?"
#         params.append(filter_status)

#     if search_query:
#         sql += " AND title LIKE ?"
#         params.append(f"%{search_query}%")

#     cur.execute(sql, tuple(params))
#     tasks = cur.fetchall()
#     conn.close()

#     return render_template("index.html", tasks=tasks,
#                            filter=filter_status, search=search_query,
#                            current_date=str(date.today()))


# @app.route("/add", methods=["GET", "POST"])
# @login_required
# def add():
#     if request.method == "POST":
#         title = request.form["title"]
#         description = request.form["description"]
#         priority = request.form["priority"]
#         due_date = request.form["due_date"]
#         status = request.form["status"]

#         conn = get_connection()
#         cur = conn.cursor()
#         cur.execute('''INSERT INTO tasks (title, description, priority, due_date, status, user_id)
#                        VALUES (?, ?, ?, ?, ?, ?)''',
#                     (title, description, priority, due_date, status, current_user.id))
#         conn.commit()
#         conn.close()
#         flash("Task added successfully!", "success")
#         return redirect(url_for("index"))

#     return render_template("add.html")


# @app.route("/edit/<int:id>", methods=["GET", "POST"])
# @login_required
# def edit(id):
#     conn = get_connection()
#     cur = conn.cursor()

#     if request.method == "POST":
#         title = request.form["title"]
#         description = request.form["description"]
#         priority = request.form["priority"]
#         due_date = request.form["due_date"]
#         status = request.form["status"]

#         cur.execute('''UPDATE tasks
#                        SET title=?, description=?, priority=?, due_date=?, status=?
#                        WHERE id=? AND user_id=?''',
#                     (title, description, priority, due_date, status, id, current_user.id))
#         conn.commit()
#         conn.close()
#         flash("Task updated!", "info")
#         return redirect(url_for("index"))

#     cur.execute("SELECT * FROM tasks WHERE id=? AND user_id=?", (id, current_user.id))
#     task = cur.fetchone()
#     conn.close()

#     return render_template("edit.html", task=task)


# @app.route("/delete/<int:id>")
# @login_required
# def delete(id):
#     conn = get_connection()
#     cur = conn.cursor()
#     cur.execute("DELETE FROM tasks WHERE id=? AND user_id=?", (id, current_user.id))
#     conn.commit()
#     conn.close()
#     flash("Task deleted!", "danger")
#     return redirect(url_for("index"))


# @app.route("/export")
# @login_required
# def export_csv():
#     conn = get_connection()
#     cur = conn.cursor()
#     cur.execute("SELECT * FROM tasks WHERE user_id=?", (current_user.id,))
#     tasks = cur.fetchall()
#     conn.close()

#     si = StringIO()
#     writer = csv.writer(si)
#     writer.writerow(["ID", "Title", "Description", "Priority", "Due Date", "Status"])
#     for task in tasks:
#         formatted_date = task[4]
#         if formatted_date:
#             try:
#                 formatted_date = datetime.strptime(formatted_date, "%Y-%m-%d").strftime("%d-%m-%Y")
#             except:
#                 pass
#         writer.writerow([task[0], task[1], task[2], task[3], formatted_date, task[5]])

#     output = si.getvalue()
#     return Response(output, mimetype="text/csv",
#                     headers={"Content-Disposition": "attachment; filename=tasks.csv"})


# if __name__ == "__main__":
#     init_db()
#     app.run(debug=True, host="0.0.0.0", port=8080)
# app.py
from flask import Flask, render_template, request, redirect, url_for, flash, Response, session
from flask_login import LoginManager, login_user, login_required, logout_user, current_user, UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from db_config import get_connection, init_db
from datetime import datetime, date
import csv
from io import StringIO

app = Flask(__name__)
app.secret_key = 'apy'

# Flask-Login setup
login_manager = LoginManager(app)
login_manager.login_view = "login"


# ----------------- USER MODEL -----------------
class User(UserMixin):
    def __init__(self, id_, username, email, password):
        self.id = id_
        self.username = username
        self.email = email
        self.password = password


@login_manager.user_loader
def load_user(user_id):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM users WHERE id=?", (user_id,))
    row = cur.fetchone()
    conn.close()
    if row:
        return User(row[0], row[1], row[2], row[3])
    return None


# ----------------- AUTH ROUTES -----------------
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form["username"].strip()
        email = request.form["email"].strip()
        password = generate_password_hash(request.form["password"])

        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute("INSERT INTO users (username, email, password) VALUES (?, ?, ?)",
                        (username, email, password))
            conn.commit()
            flash("Registration successful! Please log in.", "success")
            return redirect(url_for("login"))
        except Exception:
            flash("Username or Email already exists.", "danger")
        finally:
            conn.close()
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"].strip()
        password = request.form["password"]

        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT * FROM users WHERE email=?", (email,))
        user = cur.fetchone()
        conn.close()

        if user and check_password_hash(user[3], password):
            user_obj = User(user[0], user[1], user[2], user[3])
            login_user(user_obj)
            flash("Login successful!", "success")
            # ✅ Redirect to home page instead of dashboard
            return redirect(url_for("home"))
        else:
            flash("Invalid credentials!", "danger")

    return render_template("login.html")


@app.route("/logout")
@login_required
def logout():
    logout_user()
    flash("You have been logged out.", "info")
    return redirect(url_for("login"))


# ----------------- TASK ROUTES -----------------
@app.route("/")
def home():
    """Public landing page"""
    return render_template("home.html")


@app.route("/dashboard")
@login_required
def dashboard():
    filter_status = request.args.get('filter')
    search_query = request.args.get('search', '').strip()

    conn = get_connection()
    cur = conn.cursor()

    sql = "SELECT * FROM tasks WHERE user_id=?"
    params = [current_user.id]

    if filter_status:
        sql += " AND status=?"
        params.append(filter_status)

    if search_query:
        sql += " AND title LIKE ?"
        params.append(f"%{search_query}%")

    cur.execute(sql, tuple(params))
    tasks = cur.fetchall()
    conn.close()

    return render_template("index.html", tasks=tasks,
                           filter=filter_status, search=search_query,
                           current_date=str(date.today()))


@app.route("/add", methods=["GET", "POST"])
@login_required
def add():
    if request.method == "POST":
        title = request.form["title"]
        description = request.form["description"]
        priority = request.form["priority"]
        due_date = request.form["due_date"]
        status = request.form["status"]

        conn = get_connection()
        cur = conn.cursor()
        cur.execute('''INSERT INTO tasks (title, description, priority, due_date, status, user_id)
                       VALUES (?, ?, ?, ?, ?, ?)''',
                    (title, description, priority, due_date, status, current_user.id))
        conn.commit()
        conn.close()
        flash("Task added successfully!", "success")
        return redirect(url_for("dashboard"))

    return render_template("add.html")


@app.route("/edit/<int:id>", methods=["GET", "POST"])
@login_required
def edit(id):
    conn = get_connection()
    cur = conn.cursor()

    if request.method == "POST":
        title = request.form["title"]
        description = request.form["description"]
        priority = request.form["priority"]
        due_date = request.form["due_date"]
        status = request.form["status"]

        cur.execute('''UPDATE tasks
                       SET title=?, description=?, priority=?, due_date=?, status=?
                       WHERE id=? AND user_id=?''',
                    (title, description, priority, due_date, status, id, current_user.id))
        conn.commit()
        conn.close()
        flash("Task updated!", "info")
        return redirect(url_for("dashboard"))

    cur.execute("SELECT * FROM tasks WHERE id=? AND user_id=?", (id, current_user.id))
    task = cur.fetchone()
    conn.close()

    return render_template("edit.html", task=task)


@app.route("/delete/<int:id>")
@login_required
def delete(id):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM tasks WHERE id=? AND user_id=?", (id, current_user.id))
    conn.commit()
    conn.close()
    flash("Task deleted!", "danger")
    return redirect(url_for("dashboard"))


@app.route("/export")
@login_required
def export_csv():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM tasks WHERE user_id=?", (current_user.id,))
    tasks = cur.fetchall()
    conn.close()

    si = StringIO()
    writer = csv.writer(si)
    writer.writerow(["ID", "Title", "Description", "Priority", "Due Date", "Status"])
    for task in tasks:
        formatted_date = task[4]
        if formatted_date:
            try:
                formatted_date = datetime.strptime(formatted_date, "%Y-%m-%d").strftime("%d-%m-%Y")
            except:
                pass
        writer.writerow([task[0], task[1], task[2], task[3], formatted_date, task[5]])

    output = si.getvalue()
    return Response(output, mimetype="text/csv",
                    headers={"Content-Disposition": "attachment; filename=tasks.csv"})


# ----------------- MAIN -----------------
if __name__ == "__main__":
    init_db()
    app.run(debug=True, host="0.0.0.0", port=8080)
