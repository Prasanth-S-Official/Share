from flask import Flask, render_template, request, redirect, url_for, flash, Response
from db_config import get_connection
from datetime import datetime, date
import csv
from io import StringIO

app = Flask(__name__)
app.secret_key = 'apy'

def init_db():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute('''
        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT,
            priority TEXT,
            due_date TEXT,
            status TEXT
        )
    ''')
    conn.commit()
    conn.close()

@app.route('/')
def index():
    filter_status = request.args.get('filter')
    search_query = request.args.get('search', '').strip()

    conn = get_connection()
    cur = conn.cursor()

    sql = "SELECT * FROM tasks WHERE 1=1"
    params = []

    if filter_status:
        sql += " AND status = ?"
        params.append(filter_status)

    if search_query:
        sql += " AND title LIKE ?"
        params.append(f"%{search_query}%")

    cur.execute(sql, tuple(params))
    tasks = cur.fetchall()
    conn.close()

    return render_template("index.html", tasks=tasks, filter=filter_status, search=search_query, current_date=str(date.today()))

@app.route('/add', methods=['GET', 'POST'])
def add():
    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        priority = request.form['priority']
        due_date = request.form['due_date']
        status = request.form['status']

        conn = get_connection()
        cur = conn.cursor()
        cur.execute('''
            INSERT INTO tasks (title, description, priority, due_date, status)
            VALUES (?, ?, ?, ?, ?)
        ''', (title, description, priority, due_date, status))
        conn.commit()
        conn.close()
        flash("Task added successfully!", "success")
        return redirect(url_for('index'))

    return render_template('add.html')

@app.route('/edit/<int:id>', methods=['GET', 'POST'])
def edit(id):
    conn = get_connection()
    cur = conn.cursor()

    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        priority = request.form['priority']
        due_date = request.form['due_date']
        status = request.form['status']

        cur.execute('''
            UPDATE tasks
            SET title=?, description=?, priority=?, due_date=?, status=?
            WHERE id=?
        ''', (title, description, priority, due_date, status, id))
        conn.commit()
        conn.close()
        flash("Task updated!", "info")
        return redirect(url_for('index'))

    cur.execute("SELECT * FROM tasks WHERE id=?", (id,))
    task = cur.fetchone()
    conn.close()

    if task[4]:
        formatted_task = list(task)
        try:
            formatted_task[4] = datetime.strptime(task[4], '%Y-%m-%d').strftime('%Y-%m-%d')
        except:
            formatted_task[4] = task[4]
        task = tuple(formatted_task)

    return render_template('edit.html', task=task)

@app.route('/delete/<int:id>')
def delete(id):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM tasks WHERE id=?", (id,))
    conn.commit()
    conn.close()
    flash("Task deleted!", "danger")
    return redirect(url_for('index'))

@app.route('/export')
def export_csv():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM tasks")
    tasks = cur.fetchall()
    conn.close()

    si = StringIO()
    writer = csv.writer(si)
    writer.writerow(["ID", "Title", "Description", "Priority", "Due Date", "Status"])
    for task in tasks:
        formatted_date = task[4]
        if formatted_date:
            try:
                formatted_date = datetime.strptime(formatted_date, '%Y-%m-%d').strftime('%d-%m-%Y')
            except:
                pass
        writer.writerow([task[0], task[1], task[2], task[3], formatted_date, task[5]])

    output = si.getvalue()
    return Response(output, mimetype="text/csv", headers={"Content-Disposition": "attachment; filename=tasks.csv"})

if __name__ == '__main__':
    init_db()
    app.run(debug=True, host="0.0.0.0", port=8080)
