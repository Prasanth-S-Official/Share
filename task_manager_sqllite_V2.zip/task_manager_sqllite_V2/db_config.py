# db_config.py
import sqlite3

def get_connection():
    return sqlite3.connect("appdb.sqlite")
